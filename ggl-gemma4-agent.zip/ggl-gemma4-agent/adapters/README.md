Planned: loc_lora/ and coder_lora/ (PEFT LoRA: adapter_config.json + adapter_model.safetensors).
