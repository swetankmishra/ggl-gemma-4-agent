---
name: extract_evidence
description: Parse a GitHub issue's text into structured localization evidence — traceback frames, file paths, identifiers, error types and code snippets — as JSON.
---

# extract_evidence

Use this first when localizing an issue. It pulls the concrete clues out of long issue
text, so you do not have to spot them yourself.

## Usage

Save the issue text to a file, then run:

```bash
python scripts/extract_evidence.py /tmp/issue.txt
```

Or pipe it on stdin:

```bash
cat /tmp/issue.txt | python scripts/extract_evidence.py -
```

## Output

JSON with these keys:

- `traceback_frames`: `{file, line, function}` for each frame, innermost last
- `file_paths`: source paths mentioned anywhere
- `identifiers`: code-like names (backticked, dotted or CamelCase/snake_case calls)
- `error_types`: exception names such as `ValueError`
- `code_blocks`: fenced code snippets (first 400 characters each)

Use frames and identifiers as direct seeds. Pass code blocks to `search_similar_code`.
