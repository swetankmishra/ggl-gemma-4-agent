#!/usr/bin/env python3
"""Extract localization evidence from GitHub issue text. Prints JSON.

Usage: extract_evidence.py <issue.txt | ->
"""
import json
import re
import sys

FRAME_RE = re.compile(r'File "([^"]+)", line (\d+), in ([\w<>.]+)')
PATH_RE = re.compile(r'(?<![\w/.-])((?:[\w.-]+/)*[\w.-]+\.(?:py|pyx|pyi|js|ts|java|go|rs|c|cc|cpp|h|rb))\b')
BACKTICK_RE = re.compile(r'`([^`\n]{2,80})`')
DOTTED_RE = re.compile(r'\b([A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)+)\b')
CALL_RE = re.compile(r'\b([A-Za-z_][\w]*)\(')
ERROR_RE = re.compile(r'\b([A-Z][A-Za-z]*(?:Error|Exception|Warning))\b')
FENCE_RE = re.compile(r'```[\w+-]*\n(.*?)```', re.S)

STOP = {
    "print", "len", "str", "int", "list", "dict", "set", "range", "type", "isinstance",
    "e.g", "i.e", "etc", "self", "return", "import", "from", "def", "class",
}


def uniq(items):
    seen, out = set(), []
    for item in items:
        if item not in seen:
            seen.add(item)
            out.append(item)
    return out


def looks_like_code(name):
    return (
        name not in STOP
        and not re.fullmatch(r'\d+(\.\d+)*', name)          # version numbers
        and not re.fullmatch(r'[\w.-]+\.(com|org|io|net)', name)  # domains
    )


def extract(text):
    frames = [
        {"file": f, "line": int(n), "function": fn}
        for f, n, fn in FRAME_RE.findall(text)
    ]
    paths = uniq([f["file"] for f in frames] + PATH_RE.findall(text))

    idents = []
    for raw in BACKTICK_RE.findall(text):
        idents.extend(re.findall(r'[A-Za-z_][\w.]*', raw))
    idents += DOTTED_RE.findall(text)
    idents += CALL_RE.findall(text)
    idents += [f["function"] for f in frames]
    idents = uniq(
        i for i in idents
        if looks_like_code(i) and not PATH_RE.fullmatch(i) and len(i) > 2
    )

    return {
        "traceback_frames": frames,
        "file_paths": paths,
        "identifiers": idents[:40],
        "error_types": uniq(ERROR_RE.findall(text)),
        "code_blocks": [b.strip()[:400] for b in FENCE_RE.findall(text)][:5],
    }


def main():
    if len(sys.argv) != 2:
        print(__doc__, file=sys.stderr)
        sys.exit(2)
    src = sys.argv[1]
    text = sys.stdin.read() if src == "-" else open(src, encoding="utf-8", errors="replace").read()
    print(json.dumps(extract(text), indent=2))


if __name__ == "__main__":
    main()
