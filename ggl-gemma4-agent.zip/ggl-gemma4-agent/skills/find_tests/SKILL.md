---
name: find_tests
description: Find the existing test files most likely to cover an edited source file or symbol, and print a pytest command to run them.
---

# find_tests

Use this after editing, to run the nearest existing tests instead of the whole suite.

## Usage

Run from the repository root (`/workspace`):

```bash
python scripts/find_tests.py path/to/module.py [symbol_name]
```

## How it ranks tests

1. Files named after the module (`test_<module>.py`, `<module>_test.py`) anywhere under the repo.
2. Test files that import the module.
3. Test files that mention the symbol, when one is given.

## Output

JSON with `tests` (ranked paths, at most 8) and `command` (a ready pytest command).
If nothing is found, `tests` is empty: fall back to your reproduction script.
