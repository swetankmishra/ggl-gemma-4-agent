#!/usr/bin/env python3
"""Find tests nearest to an edited source file (and optional symbol). Prints JSON.

Usage: find_tests.py <path/to/module.py> [symbol] [--root DIR]
"""
import json
import os
import sys

SKIP_DIRS = {".git", "node_modules", "__pycache__", ".tox", ".venv", "venv", "build", "dist", ".eggs"}
MAX_TESTS = 8
MAX_BYTES = 400_000


def is_test_file(name):
    return name.endswith(".py") and (name.startswith("test_") or name.endswith("_test.py"))


def walk_tests(root):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            if is_test_file(name):
                yield os.path.relpath(os.path.join(dirpath, name), root)


def module_dotted(path):
    p = path[:-3] if path.endswith(".py") else path
    parts = [x for x in p.replace(os.sep, "/").split("/") if x not in ("", ".", "src", "lib")]
    if parts and parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def read(path):
    try:
        if os.path.getsize(path) > MAX_BYTES:
            return ""
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


def find(src, symbol=None, root="."):
    stem = os.path.splitext(os.path.basename(src))[0]
    if stem == "__init__":
        stem = os.path.basename(os.path.dirname(src)) or stem
    dotted = module_dotted(src)
    tail = dotted.split(".")[-1] if dotted else stem

    scored = []
    for t in walk_tests(root):
        name = os.path.basename(t)
        score = 0
        if name in (f"test_{stem}.py", f"{stem}_test.py"):
            score += 10
        elif stem in name:
            score += 4
        text = read(os.path.join(root, t))
        if dotted and (f"import {dotted}" in text or f"from {dotted}" in text):
            score += 6
        elif f"import {tail}" in text or f" {tail} import" in text:
            score += 2
        if symbol and symbol in text:
            score += 5
        if score:
            scored.append((score, t))

    scored.sort(key=lambda x: (-x[0], x[1]))
    tests = [t for _, t in scored[:MAX_TESTS]]
    cmd = ("python -m pytest -x -q " + " ".join(tests)) if tests else ""
    if tests and symbol:
        cmd += f" -k {symbol}"
    return {"source": src, "symbol": symbol, "tests": tests, "command": cmd}


def main():
    args = sys.argv[1:]
    root = "."
    if "--root" in args:
        i = args.index("--root")
        root = args[i + 1]
        del args[i:i + 2]
    if not args or len(args) > 2:
        print(__doc__, file=sys.stderr)
        sys.exit(2)
    src = args[0]
    symbol = args[1] if len(args) == 2 else None
    print(json.dumps(find(src, symbol, root), indent=2))


if __name__ == "__main__":
    main()
